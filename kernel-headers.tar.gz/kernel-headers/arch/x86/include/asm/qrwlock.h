/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _ASM_X86_QRWLOCK_H
#define _ASM_X86_QRWLOCK_H

#include <asm-generic/qrwlock_types.h>
#include <asm-generic/qrwlock.h>

#endif /* _ASM_X86_QRWLOCK_H */
