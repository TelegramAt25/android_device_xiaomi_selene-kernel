/* SPDX-License-Identifier: GPL-2.0 */
#ifndef _ASM_X86_MISC_H
#define _ASM_X86_MISC_H

int num_digits(int val);

#endif /* _ASM_X86_MISC_H */
