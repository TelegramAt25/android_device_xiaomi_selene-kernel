/* SPDX-License-Identifier: GPL-2.0 */
#ifdef CONFIG_64BIT
#define KSYM_ALIGN 16
#endif
#include <asm-generic/export.h>
